import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-hospital',
  templateUrl: './delete-hospital.component.html',
  styleUrls: ['./delete-hospital.component.css']
})
export class DeleteHospitalComponent {

}
