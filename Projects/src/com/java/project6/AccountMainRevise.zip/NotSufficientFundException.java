package com.java.project6;

public class NotSufficientFundException extends Exception	 {

	public NotSufficientFundException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
